import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { UtilService } from './services/util.service';

export interface PeriodicElement {
  nearest_compound: string;
  distance: number;
  toxic_level: number;
  Probability: number;
  smile: number;
  jnj_id: number;
  SA_matches: number;
  nearestCompounds: number;
  final_remarks: number;
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  totalCount:any;

  sanitize(data: any) {
    let jsonArray: any = [];
    Object.entries(data).forEach(([k, v]) => {
      if(typeof v == "object")
      jsonArray.push(v)
    })
    console.log(jsonArray);
    return jsonArray;
  }
  title = 'glugal';
  public showMore = true;
  public showcontent = true;
  public analysis = true;
  public tableData: any = [];
  public formData: any;
  public nearestCompounds: any = [];
  public saMatches: any = [];

  file = new FormGroup({
    fileUploded: new FormControl('', Validators.required)
  })
  constructor(private util: UtilService) {
    console.log(this.file)
  }
  moreInfo(datas: any) {
    this.saMatches = datas
    this.showMore = false;
    if (this.showcontent = true) {
      this.showcontent = true;
    }

  }
  content(data: any) {
    this.nearestCompounds = data;
    if (this.showMore = true) {
      this.showcontent = false;
    }
  }

  runanalysis() {
    const formData = new FormData();
    formData.append('file', this.formData);
    // this.util.getGluGalData(formData).subscribe(result =>{
    //   this.tableData = result; 
    //   this.analysis=false;
    // })
    this.analysis = false;
  }

  onFileSelected(data: any) {
    this.formData = data.files[0];
  }

  downloadCSv(rows: any) {
    let csvContent = "data:text/csv;charset=utf-8,";
    let data = rows[0];
    data[0].forEach((rowArray: any) => {
      let row = rowArray.join(",");
      csvContent += row + "\r\n";
    });
    var encodedUri = encodeURI(csvContent);
    var link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "data.csv");
    document.body.appendChild(link); // Required for FF
    link.click(); // This will download the data file named "my_data.csv"
  }


  displayedColumnsLeft: string[] = ['nearest_compound', 'distance', 'toxic_level'];
  displayedColumnsRight: string[] = ['smile', 'jnj_id', 'SA_matches', 'nearestCompounds', 'final_remarks', 'Probability']
}
