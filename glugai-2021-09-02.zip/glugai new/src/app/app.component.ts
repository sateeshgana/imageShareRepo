import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { UtilService } from './services/util.service';

export interface PeriodicElement {
  nearest_compound: string;
  distance: number;
  toxic_level:number;
  Probability:number;
  smile:number;
  jnj_id:number;
  SA_matches:number;
  nearestCompounds:number;
  final_remarks:number;
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  sanitize(data:any){
    let jsonArray:any = [];
    Object.entries(data).forEach(([k, v]) =>{
     jsonArray.push(v)
    })
    console.log(jsonArray);
    return jsonArray;
  }
  title = 'glugal';
  public showMore = true;
  public showcontent=true;
  public analysis=true;
  public tableData:any= [];
  public formData:any;
  public nearestCompounds:any=[];
  public saMatches:any=[];
  
  file=new FormGroup({
    fileUploded:new FormControl('',Validators.required)
  })
  constructor(private util:UtilService){
    console.log(this.file)
  }
  moreInfo(datas:any){
    this.saMatches=datas
    this.showMore = false;
    if(this.showcontent=true){
      this.showcontent=true;
    }
   
  }
  content(data:any){
    this.nearestCompounds = data;
    if(this.showMore=true){
      this.showcontent=false;
    }
  }
  
  runanalysis(){
    const formData = new FormData();
    formData.append('file', this.formData);
    this.util.getGluGalData(formData).subscribe(result =>{
      this.tableData = result; 
      this.analysis=false;
    })
   
  }

  onFileSelected(data:any)
  {
     this.formData = data.files[0];
  }
  displayedColumnsLeft: string[] = ['nearest_compound', 'distance','toxic_level'];
  displayedColumnsRight:string[]=['smile','jnj_id','SA_matches','nearestCompounds','final_remarks','Probability']
}
