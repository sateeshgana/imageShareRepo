import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { UtilService } from './services/util.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  sanitize(data:any){
    let jsonArray:any = [];
    Object.entries(data).forEach(([k, v]) =>{
     jsonArray.push(v)
    })
    console.log(jsonArray);
    return jsonArray;
  }
  title = 'glugal';
  public showMore = true;
  public showcontent=true;
  public analysis=false;
  public tableData:any= this.sanitize(this.util.samleData.result);
  public formData:any;
  public nearestCompounds:any=[];
  
  file=new FormGroup({
    fileUploded:new FormControl('',Validators.required)
  })
  constructor(private util:UtilService){
    console.log(this.file)
  }
  moreInfo(){
    this.showMore = false;
    if(this.showcontent=true){
      this.showcontent=true;
    }
   
  }
  content(data:any){
    this.nearestCompounds = data;
    if(this.showMore=true){
      this.showcontent=false;
    }
  }
  
  runanalysis(){
    const formData = new FormData();
    formData.append('file', this.formData);
    this.util.getGluGalData(formData).subscribe(result =>{
      this.tableData = result; 
      this.analysis=false;
    })
   
  }

  onFileSelected(data:any)
  {
     this.formData = data.files[0];
  }
 
}
