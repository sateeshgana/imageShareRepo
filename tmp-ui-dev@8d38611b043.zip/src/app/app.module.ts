import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AuthenticationComponent } from './authentication/authentication.component';
import { LoginComponent } from './home/components/login/login.component';
import { ReactiveFormsModule } from '@angular/forms';
import { HeaderComponent } from './header/header.component';
import { MatCardModule } from '@angular/material/card';
import {AccordionModule} from 'primeng/accordion';     //accordion and accordion tab
import {MenuItem} from 'primeng/api';
import { TechnicianDefaultComponent } from './shared/components/technician-default/technician-default.component';                  //api
import { CardModule} from 'primeng/card';
import {TabViewModule} from 'primeng/tabview';
import { FormsModule } from '@angular/forms';
import {InputTextModule} from 'primeng/inputtext';
import { DropdownModule } from "primeng/dropdown";
import {Product} from './Product';
import { TableModule } from 'primeng/table';
import { ProductService} from './productservice';
import { HttpClientModule } from '@angular/common/http';
import {MatToolbarModule} from '@angular/material/toolbar'; 
import { RouterModule } from '@angular/router';
import { ScientistDefaultComponent } from './shared/components/scientist-default/scientist-default.component';
import { PathologistDefaultComponent } from './shared/components/pathologist-default/pathologist-default.component';
import {DialogModule} from 'primeng/dialog';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';




@NgModule({
  declarations: [
    AppComponent,
    AuthenticationComponent,
    LoginComponent,
    HeaderComponent,
    TechnicianDefaultComponent,
    ScientistDefaultComponent,
    PathologistDefaultComponent,
  ],
  imports: [
    RouterModule,
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    MatCardModule,
    TabViewModule,
    FormsModule,
    InputTextModule,
    DropdownModule,
    TableModule,
    HttpClientModule,
    MatToolbarModule,
    DialogModule,
    BrowserAnimationsModule
  ],
  providers: [ProductService],
  bootstrap: [AppComponent]
})
export class AppModule { }
