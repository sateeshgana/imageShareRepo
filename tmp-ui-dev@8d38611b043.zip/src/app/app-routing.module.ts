import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './home/components/login/login.component';
import { HeaderComponent } from './header/header.component';
import { TechnicianDefaultComponent } from './shared/components/technician-default/technician-default.component';
import { CommonModule } from '@angular/common';

const routes: Routes = [];

@NgModule({
  imports: [RouterModule.forRoot(routes,{relativeLinkResolution:'legacy'}),CommonModule],
  exports: [RouterModule]
})
export class AppRoutingModule {
   routes: Routes = [
    // {
    //   path:'',
    //   component:TechnicianDefaultComponent
    // },
      { 
        path: 'abc', 
        component: TechnicianDefaultComponent 
      },
  
  ];
 }


