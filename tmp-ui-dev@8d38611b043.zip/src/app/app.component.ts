import { Component } from '@angular/core';
import { ProductService } from './productservice';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'TMP';
  showLogin=true;
  showTechnician=false;

  constructor(private service:ProductService){}

  ngOnInit(): void {
  this.service.routerFlag.subscribe(result => {
    this.service.currentRole = result;
    if(result == 'scientist'){      
      this.showTechnician = true;
      this.showLogin = false;
    }else if(result === "technician"){
      this.showTechnician = true;
      this.showLogin = false;
    }else if(result === "Admin"){
      this.showTechnician = true;
      this.showLogin = false;
    }else if(result === "Pathologist"){
      this.showTechnician = true;
      this.showLogin = false;
    }
    else{
      this.showLogin=true;
      this.showTechnician=false;
    }
    })

    
  }

}

