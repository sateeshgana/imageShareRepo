import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { TechnicianDefaultComponent } from '../../../shared/components/technician-default/technician-default.component'
import { ProductService } from 'src/app/productservice';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  role:any = ""

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,private router: Router,
    private service:ProductService
  ) { 
    
  }

  ngOnInit(): void {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
  });
  }
  onSubmit() {
   
}
navigate(){
  console.log("role",this.role)
  if(this.role === "Admin"){
    this.service.routerFlag.next('Admin');
  }else if(this.role === "Technician"){
    this.service.routerFlag.next('technician');
  }else if(this.role === "Scientist"){
    this.service.routerFlag.next('scientist');
  }else if(this.role === "Pathologist"){
    this.service.routerFlag.next('Pathologist');
  }
  console.log("service",this.service)
  // this.service.routerFlag.next('scientist');
  // this.router.navigate(['/abc']);
}

}
