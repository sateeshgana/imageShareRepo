import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GlossaryDefaultComponent } from './glossary-default.component';

describe('GlossaryDefaultComponent', () => {
  let component: GlossaryDefaultComponent;
  let fixture: ComponentFixture<GlossaryDefaultComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GlossaryDefaultComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GlossaryDefaultComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
