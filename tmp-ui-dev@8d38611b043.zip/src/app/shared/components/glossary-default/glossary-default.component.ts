import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ProductService } from '../../../productservice';
import { Product } from '../../../Product';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
@Component({
  selector: 'app-glossary-default',
  templateUrl: './glossary-default.component.html',
  styleUrls: ['./glossary-default.component.css']
})
export class GlossaryDefaultComponent implements OnInit {
  pathologistForm: FormGroup;

  // scientistForm2: FormGroup;
  submitted = false;
  products: Product[];


  searchField : '';
  selectedState: any = null;

  states: any[] = [
    { name: "Arizona", code: "Arizona" },
    { name: "California", value: "California" },
    { name: "Florida", code: "Florida" },
    { name: "Ohio", code: "Ohio" },
    { name: "Washington", code: "Washington" }
  ];

  cities1: any[] = [];

  cities2: any[] = [];

  city1: any = null;

  city2: any = null;
  isscientist:any=false;
  ispathologist:any=false;
  istechnician:any = false


  constructor(private formBuilder: FormBuilder, private productService: ProductService,private router:Router) { }
  

  ngOnInit(): void {
    if(this.productService.currentRole == 'technician'){

       this.istechnician = true
    }
    else if(this.productService.currentRole == 'scientist'){


      this.isscientist = true
    }
    else if(this.productService.currentRole == 'Pathologist'){

    
      this.ispathologist = true
    }
  }

}
