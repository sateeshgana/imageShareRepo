import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ProductService } from '../../../productservice';
import { Product } from '../../../Product';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
@Component({
  selector: 'app-scientist-default',
  templateUrl: './scientist-default.component.html',
  styleUrls: ['./scientist-default.component.css']
})
export class ScientistDefaultComponent implements OnInit {
  scientistForm: FormGroup;

  scientistForm2: FormGroup;
  submitted = false;
  products: Product[];


  searchField : '';
  selectedState: any = null;

  states: any[] = [
    { name: "Arizona", code: "Arizona" },
    { name: "California", value: "California" },
    { name: "Florida", code: "Florida" },
    { name: "Ohio", code: "Ohio" },
    { name: "Washington", code: "Washington" }
  ];

  cities1: any[] = [];

  cities2: any[] = [];

  city1: any = null;

  city2: any = null;

  constructor(private formBuilder: FormBuilder, private productService: ProductService,private router:Router) { }

  ngOnInit(): void {
    this.scientistForm = this.formBuilder.group({
      // studeID: ['', Validators.required],
      species: ['', Validators.required],
      targetID: ['', Validators.required],
      // validates date format yyyy-mm-dd
      tissue: ['', [Validators.required]],
      donorID: ['', [Validators.required]],
      format: ['', [Validators.required]],
      matrix: ['', Validators.required],
      technician : ['', Validators.required],
      imageID : ['', Validators.required],
      modality : ['', Validators.required],
      modalityProbe : ['', Validators.required],
      visualisation : ['', Validators.required],
    levels : ['', Validators.required],
  }, );
  this.scientistForm2 = this.formBuilder.group({
    // studeID: ['', Validators.required],
    read: ['', Validators.required],
    scientist: ['', Validators.required],
    // validates date format yyyy-mm-dd
    organSystem: ['', [Validators.required]],
    cellTypes: ['', [Validators.required]],
    measure: ['', [Validators.required]],
    cellFractions: ['', Validators.required],
    pattern : ['', Validators.required],
    status   : ['', Validators.required],
    comments : ['', Validators.required],
    



}, );
  this.productService.getProductsSmall().then((data : any) => this.products = data);
  }
  }


