import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ScientistDefaultComponent } from './scientist-default.component';

describe('ScientistDefaultComponent', () => {
  let component: ScientistDefaultComponent;
  let fixture: ComponentFixture<ScientistDefaultComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ScientistDefaultComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ScientistDefaultComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
