import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ProductService } from '../../../productservice';
import { Product } from '../../../Product';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { TabPanel } from 'primeng/tabview/tabview';
import {CalendarModule} from 'primeng/calendar';
// import { TabPanel } from 'primeng/tabview/tabview';



@Component({
  selector: 'app-technician-default',
  templateUrl: './technician-default.component.html',
  styleUrls: ['./technician-default.component.css']
})
export class TechnicianDefaultComponent implements OnInit {
  registerForm: FormGroup;
  submitted = false;
  products: Product[];
  products2:[];
  display=false;
  userRole:any='';
  showScientistTab : boolean = false;
  showPathologistTab : boolean = false;
  scientistForm2: FormGroup;
  tabs :any = '';
  msg:string
  date:any="";
  columnspopUp:any=false;
  searchField : '';
  selectedState: any = null;
  states: any[] = [
    { name: "Arizona", code: "Arizona" },
    { name: "California", value: "California" },
    { name: "Florida", code: "Florida" },
    { name: "Ohio", code: "Ohio" },
    { name: "Washington", code: "Washington" }
  ];
  cities1: any[] = [];
  cities2: any[] = [];
  city1: any = null;
  count:any=0;
  city2: any = null;
  today:any = true;
  week:any;
  month:any;
  slide:any;
  image:any;
  study:any;
  species:any;
  target:any;
  tissue:any;
  donor:any;
  matrix:any;
  format:any;
  levels:any;
  technicianname:any;
  pathologistname:any;
  modalityprode:any;
  visualisation:any;
  read:any;
  scientist:any;
  organsystemassignment:any;
  celltype:any;
  measure:any;
  cellfraction:any;
  pattern:any;
  status:any;
  scientistname:any;
  masterSelected:boolean;
  checklist:any;
  step2headers:any;
  checkedList:any;
  checkedList2:any
  checklist2:any;
  headers:any=[];
  totalcheckedList:any;
  cols:any;
  steps:any=[];
  multipleSelection:any=[];
  index: number = 0;
  count1: number = 0;
  isrow:any = false;
  isadmin:any = false
  istechnician:any = false;
  ispathologist:any = false;
  isscientist:any = false
  
  constructor(private formBuilder: FormBuilder, private productService: ProductService,private router:Router) {
    this.cols = [
      { SlideID: '5123456789', ImageID: 'ImageID',StudyID: 'Study567' ,Species: 'Human' ,TargetID: 'Tar123' ,Tissue: 'Tissue' ,DonorID: 'DID235654' ,
      Matrix: 'XX' ,Format: 'XX' , Levels: 'Levels' ,Modality: 'Modality' , TechnicianName: 'TechnicianName' ,PathologistName: 'PathologistName' ,
      ModalityProde: 'ModalityProde' ,Visualisation: 'Visualisation' , Read: 'Read' ,Scientist: 'Scientist' , OrganSystemAssignment: 'OrganSystemAssignment' ,CellTypes: 'CellTypes' ,
      Measure: 'Measure' ,CellFractions: 'CellFractions' , Pattern: 'Pattern' ,Status: 'Status' , ScientistName: 'ScientistName'},
      { SlideID: '5123456788', ImageID: 'ImageID',StudyID: 'Study567' ,Species: 'Human' ,TargetID: 'Tar123' ,Tissue: 'Tissue' ,DonorID: 'DID235654' ,
      Matrix: 'XX' ,Format: 'XX' , Levels: 'Levels' ,Modality: 'Modality' , TechnicianName: 'TechnicianName' ,PathologistName: 'PathologistName' ,
      ModalityProde: 'ModalityProde' ,Visualisation: 'Visualisation' , Read: 'Read' ,Scientist: 'Scientist' , OrganSystemAssignment: 'OrganSystemAssignment' ,CellTypes: 'CellTypes' ,
      Measure: 'Measure' ,CellFractions: 'CellFractions' , Pattern: 'Pattern' ,Status: 'Status' , ScientistName: 'ScientistName'},
      { SlideID: '5123456783', ImageID: 'ImageID',StudyID: 'Study567' ,Species: 'Human' ,TargetID: 'Tar123' ,Tissue: 'Tissue' ,DonorID: 'DID235654' ,
      Matrix: 'XX' ,Format: 'XX' , Levels: 'Levels' ,Modality: 'Modality' , TechnicianName: 'TechnicianName' ,PathologistName: 'PathologistName' ,
      ModalityProde: 'ModalityProde' ,Visualisation: 'Visualisation' , Read: 'Read' ,Scientist: 'Scientist' , OrganSystemAssignment: 'OrganSystemAssignment' ,CellTypes: 'CellTypes' ,
      Measure: 'Measure' ,CellFractions: 'CellFractions' , Pattern: 'Pattern' ,Status: 'Status' , ScientistName: 'ScientistName'},
      { SlideID: '5123456783', ImageID: 'ImageID',StudyID: 'Study567' ,Species: 'Human' ,TargetID: 'Tar123' ,Tissue: 'Tissue' ,DonorID: 'DID235654' ,
      Matrix: 'XX' ,Format: 'XX' , Levels: 'Levels' ,Modality: 'Modality' , TechnicianName: 'TechnicianName' ,PathologistName: 'PathologistName' ,
      ModalityProde: 'ModalityProde' ,Visualisation: 'Visualisation' , Read: 'Read' ,Scientist: 'Scientist' , OrganSystemAssignment: 'OrganSystemAssignment' ,CellTypes: 'CellTypes' ,
      Measure: 'Measure' ,CellFractions: 'CellFractions' , Pattern: 'Pattern' ,Status: 'Status' , ScientistName: 'ScientistName'},
      { SlideID: '5123456782', ImageID: 'ImageID',StudyID: 'Study567' ,Species: 'Human' ,TargetID: 'Tar123' ,Tissue: 'Tissue' ,DonorID: 'DID235654' ,
      Matrix: 'XX' ,Format: 'XX' , Levels: 'Levels' ,Modality: 'Modality' , TechnicianName: 'TechnicianName' ,PathologistName: 'PathologistName' ,
      ModalityProde: 'ModalityProde' ,Visualisation: 'Visualisation' , Read: 'Read' ,Scientist: 'Scientist' , OrganSystemAssignment: 'OrganSystemAssignment' ,CellTypes: 'CellTypes' ,
      Measure: 'Measure' ,CellFractions: 'CellFractions' , Pattern: 'Pattern' ,Status: 'Status' , ScientistName: 'ScientistName'},
      { SlideID: '5123456781', ImageID: 'ImageID',StudyID: 'Study567' ,Species: 'Human' ,TargetID: 'Tar123' ,Tissue: 'Tissue' ,DonorID: 'DID235654' ,
      Matrix: 'XX' ,Format: 'XX' , Levels: 'Levels' ,Modality: 'Modality' , TechnicianName: 'TechnicianName' ,PathologistName: 'PathologistName' ,
      ModalityProde: 'ModalityProde' ,Visualisation: 'Visualisation' , Read: 'Read' ,Scientist: 'Scientist' , OrganSystemAssignment: 'OrganSystemAssignment' ,CellTypes: 'CellTypes' ,
      Measure: 'Measure' ,CellFractions: 'CellFractions' , Pattern: 'Pattern' ,Status: 'Status' , ScientistName: 'ScientistName'},
     

  ]; 
    this.masterSelected = false;
   
    this.step2headers = [
      {id:1,value:'Read',field: 'Read',isSelected:true},
       {id:2,value:'Scientist',field: 'Scientist',isSelected:true},
       {id:3,value:'Organ System Assignment',field: 'OrganSystemAssignment',isSelected:true},
       {id:4,value:'Cell Types',field: 'Celltypes',isSelected:true},
       {id:5,value:'Measure',field: 'measure',isSelected:true},
       {id:6,value:'Cell Fractions',field: 'Cellfractions',isSelected:true},
       {id:7,value:'Pattern',field: 'Pattern',isSelected:true},
       {id:8,value:'Status',field: 'Status',isSelected:true},
       {id:9,value:'Comments',field: 'Comments',isSelected:true},
     ];
     if(this.productService.currentRole == 'technician'){
      this.checklist = [
        {id:1,value:'Slide ID',field: 'SlideID',isSelected:true},
         {id:3,value:'Study ID',field: 'StudyID',isSelected:true},
         {id:4,value:'Species',field: 'Species',isSelected:true},
         {id:5,value:'Target ID',field: 'TargetID',isSelected:true},
         {id:6,value:'Tissue',field: 'Tissue',isSelected:true},
        
       ];
       this.checklist2 = [
        {id:7,value:'Donor ID',field: 'DonorID',isSelected:true},
        {id:8,value:'Matrix',field: 'Matrix',isSelected:true},
        {id:9,value:'Format',field: 'Format',isSelected:true},
        {id:12,value:'Technician Name',field: 'TechnicianName',isSelected:true},
      
        
       ];

    }
    if(this.productService.currentRole == 'scientist'){

      this.checklist = [
        {id:1,value:'Slide ID',field: 'SlideID',isSelected:true},
         {id:2,value:'Image ID',field: 'ImageID',isSelected:true},
         {id:3,value:'Study ID',field: 'StudyID',isSelected:true},
         {id:4,value:'Species',field: 'Species',isSelected:true},
         {id:5,value:'Target ID',field: 'TargetID',isSelected:true},
         {id:6,value:'Tissue',field: 'Tissue',isSelected:true},
         {id:7,value:'Donor ID',field: 'DonorID',isSelected:true},
         {id:8,value:'Matrix',field: 'Matrix',isSelected:true},
         {id:9,value:'Format',field: 'Format',isSelected:true},
         {id:10,value:'Levels',field: 'Levels',isSelected:true},
         {id:11,value:'Modality',field: 'Modality',isSelected:true},
         {id:12,value:'Technician Name',field: 'TechnicianName',isSelected:true},
     
       ];
       this.checklist2 = [
         {id:1,value:'Modality Prode',field: 'ModalityProde',isSelected:true},
         {id:2,value:'Visualisation',field: 'Visualisation',isSelected:true},
         {id:3,value:'Read',field: 'Read',isSelected:true},
         {id:4,value:'Scientist',field: 'Scientist',isSelected:true},
         {id:5,value:'Organ System Assignment',field: 'OrganSystemAssignment',isSelected:true},
         {id:6,value:'Cell Types',field: 'CellTypes',isSelected:true},
         {id:7,value:'Measure',field: 'Measure',isSelected:true},
         {id:8,value:'Cell Fractions',field: 'CellFractions',isSelected:true},
         {id:9,value:'Pattern',field: 'Pattern',isSelected:true},
         {id:10,value:'Status',field: 'Status',isSelected:true},
         {id:11,value:'Scientist Name',field: 'ScientistName',isSelected:true},
        
       ];
    }
    if(this.productService.currentRole == 'Pathologist'){

      this.checklist = [
        {id:1,value:'Slide ID',field: 'SlideID',isSelected:true},
         {id:2,value:'Image ID',field: 'ImageID',isSelected:true},
         {id:3,value:'Study ID',field: 'StudyID',isSelected:true},
         {id:4,value:'Species',field: 'Species',isSelected:true},
         {id:5,value:'Target ID',field: 'TargetID',isSelected:true},
         {id:6,value:'Tissue',field: 'Tissue',isSelected:true},
         {id:7,value:'Donor ID',field: 'DonorID',isSelected:true},
         {id:8,value:'Matrix',field: 'Matrix',isSelected:true},
         {id:9,value:'Format',field: 'Format',isSelected:true},
         {id:10,value:'Levels',field: 'Levels',isSelected:true},
         {id:11,value:'Modality',field: 'Modality',isSelected:true},
         {id:12,value:'Technician Name',field: 'TechnicianName',isSelected:true},
         {id:13,value:'Pathologist Name',field: 'PathologistName',isSelected:true}
       ];
       this.checklist2 = [
         {id:1,value:'Modality Prode',field: 'ModalityProde',isSelected:true},
         {id:2,value:'Visualisation',field: 'Visualisation',isSelected:true},
         {id:3,value:'Read',field: 'Read',isSelected:true},
         {id:4,value:'Scientist',field: 'Scientist',isSelected:true},
         {id:5,value:'Organ System Assignment',field: 'OrganSystemAssignment',isSelected:true},
         {id:6,value:'Cell Types',field: 'CellTypes',isSelected:true},
         {id:7,value:'Measure',field: 'Measure',isSelected:true},
         {id:8,value:'Cell Fractions',field: 'CellFractions',isSelected:true},
         {id:9,value:'Pattern',field: 'Pattern',isSelected:true},
         {id:10,value:'Status',field: 'Status',isSelected:true},
         {id:11,value:'Scientist Name',field: 'ScientistName',isSelected:true},
        
       ];
    }
    if(this.productService.currentRole == 'Admin'){
      this.checklist = [
        {id:1,value:'Slide ID',field: 'SlideID',isSelected:true},
         {id:3,value:'Study ID',field: 'StudyID',isSelected:true},
         {id:4,value:'Species',field: 'Species',isSelected:true},
         {id:5,value:'Target ID',field: 'TargetID',isSelected:true},
         {id:6,value:'Tissue',field: 'Tissue',isSelected:true},
        
       ];
       this.checklist2 = [
        {id:7,value:'Donor ID',field: 'DonorID',isSelected:true},
        {id:8,value:'Matrix',field: 'Matrix',isSelected:true},
        {id:9,value:'Format',field: 'Format',isSelected:true},
        {id:12,value:'Technician Name',field: 'TechnicianName',isSelected:true},
       ];
    }
    // this.checklist = [
    //  {id:1,value:'Slide ID',field: 'SlideID',isSelected:true},
    //   {id:2,value:'Image ID',field: 'ImageID',isSelected:true},
    //   {id:3,value:'Study ID',field: 'StudyID',isSelected:true},
    //   {id:4,value:'Species',field: 'Species',isSelected:true},
    //   {id:5,value:'Target ID',field: 'TargetID',isSelected:true},
    //   {id:6,value:'Tissue',field: 'Tissue',isSelected:true},
    //   {id:7,value:'Donor ID',field: 'DonorID',isSelected:true},
    //   {id:8,value:'Matrix',field: 'Matrix',isSelected:true},
    //   {id:9,value:'Format',field: 'Format',isSelected:true},
    //   {id:10,value:'Levels',field: 'Levels',isSelected:true},
    //   {id:11,value:'Modality',field: 'Modality',isSelected:true},
    //   {id:12,value:'Technician Name',field: 'TechnicianName',isSelected:true},
    //   {id:13,value:'Pathologist Name',field: 'PathologistName',isSelected:true}
    // ];
    // this.checklist2 = [
    //   {id:1,value:'Modality Prode',field: 'ModalityProde',isSelected:true},
    //   {id:2,value:'Visualisation',field: 'Visualisation',isSelected:true},
    //   {id:3,value:'Read',field: 'Read',isSelected:true},
    //   {id:4,value:'Scientist',field: 'Scientist',isSelected:true},
    //   {id:5,value:'Organ System Assignment',field: 'OrganSystemAssignment',isSelected:true},
    //   {id:6,value:'Cell Types',field: 'CellTypes',isSelected:true},
    //   {id:7,value:'Measure',field: 'Measure',isSelected:true},
    //   {id:8,value:'Cell Fractions',field: 'CellFractions',isSelected:true},
    //   {id:9,value:'Pattern',field: 'Pattern',isSelected:true},
    //   {id:10,value:'Status',field: 'Status',isSelected:true},
    //   {id:11,value:'Scientist Name',field: 'ScientistName',isSelected:true},
     
    // ];
    this.getCheckedItemList();
  }

  ngOnInit(): void {
    // this.multipleSelection = this.cols[n-1];
    console.log(this.productService.currentRole);
   
    this.productService.userRoles.forEach(role => {
      if(this.productService.currentRole == 'technician'){
        this.showScientistTab = true;
         this.istechnician = true
      }
      if(this.productService.currentRole == 'scientist'){

        this.showScientistTab = true;
        this.isscientist = true
      }
      if(this.productService.currentRole == 'Pathologist'){

        this.showScientistTab = true;
        this.ispathologist = true
      }
      if(this.productService.currentRole == 'Admin'){
        this.isadmin = true
        this.showScientistTab = true;
      }
    })
    console.log(this.showScientistTab);
    this.tabs = 'Step 1'
    // this.tabs = this.showScientistTab ? 'Step 1 ' : 'Create Slide ID'
    // console.log(this.tabs);
    
    // if(this.showPathologistTab)
    // this.tabs = this.showPathologistTab ? 'Step 1 ' : 'Create Slide ID'
    
    
    this.registerForm = this.formBuilder.group({
      studeID: ['', Validators.required],
      species: ['', Validators.required],
      targetID: ['', Validators.required],
      pathologistname:['', Validators.required],
      technicianname:['', Validators.required],
      scientistname:['', Validators.required],
      // validates date format yyyy-mm-dd
      tissue: ['', [Validators.required]],
      donorID: ['', [Validators.required]],
      format: ['', [Validators.required]],
      matrix: ['', Validators.required],
      technician : ['', Validators.required],
      imageID : ['', Validators.required],
      modality : ['', Validators.required],
      modalityProbe : ['', Validators.required],
      visualisation : ['', Validators.required],
      levels : ['', Validators.required],
  }, );
  this.scientistForm2 = this.formBuilder.group({
    // studeID: ['', Validators.required],
    read: ['', Validators.required],
    scientist: ['', Validators.required],
    // validates date format yyyy-mm-dd
    organSystem: ['', [Validators.required]],
    cellTypes: ['', [Validators.required]],
    measure: ['', [Validators.required]],
    cellFractions: ['', Validators.required],
    pattern : ['', Validators.required],
    status   : ['', Validators.required],
    comments : ['', Validators.required],
    pathologist : ['', Validators.required]
    



}, );
  this.productService.getProductsSmall().then((data : any) => this.products = data);
  console.log("data",this.products)
  }
  toggleColor(){
    console.log("class")
   
  }
  clickEvent(e:any){
    if(e === "week"){
      this.week = true;
      this.today = false;
      this.month = false;
    } else if(e === "today"){
      this.week = false;
    this.today = true;
    this.month = false;
    } else if(e === "month"){
      this.week = false;
     this.today = false;
    this.month = true;
    }
  }
 
  selectColumns(){
    // console.log('this',data);
    this.columnspopUp = true;

    
  }
  onRowSelect(event:any) {
    console.log(event)
  }
  onRowUnselect(event:any){
    console.log(event);
  }
  saveColumns(){
    this.columnspopUp = false;
  }
  
  generateSlideID(form:any){
    console.log(form);
    
    
  }
  addAnotherRow(){
    this.count1++;
    var data  = { Read: "1", Scientist: 'RN',OrganSystemAssignment: 'Cardiovascular' ,Celltypes: 'Myocyte' ,measure: 'High' ,Cellfractions: '100' ,Pattern: 'Cytoplasmic' , Status: 'Cytoplasmic' ,Comments: 'comments...'}; 
  this.steps.push(data)

  }
  deleteTableRow(e:any, i:any){
    console.log(e + i)
    this.cols.splice(i,1)
  }
  removeRow(e:any, i:any){
    console.log(e + i)
    this.steps.splice(i,1)
  }
  editTableRow(e:any){
    if(this.productService.currentRole == 'technician'){
      this.openNext();
    }else{
      this.isrow = true;
    this.openNext();
    }
   
  }
  closePopUp() {
    this.checklist = [
      {id:1,value:'Slide ID',isSelected:true},
       {id:2,value:'Image ID',isSelected:true},
       {id:3,value:'Study ID',isSelected:true},
       {id:4,value:'Species',isSelected:true},
       {id:5,value:'Target ID',isSelected:true},
       {id:6,value:'Tissue',isSelected:true},
       {id:7,value:'Donor ID',isSelected:true},
       {id:8,value:'Matrix',isSelected:true},
       {id:9,value:'Format',isSelected:true},
       {id:10,value:'Levels',isSelected:true},
       {id:11,value:'Modality',isSelected:true},
       {id:12,value:'Technician Name',isSelected:true},
       {id:13,value:'Pathologist Name',isSelected:true}
     ];
     this.checklist2 = [
       {id:1,value:'Modality Prode',isSelected:true},
       {id:2,value:'Visualisation',isSelected:true},
       {id:3,value:'Read',isSelected:true},
       {id:4,value:'Scientist',isSelected:true},
       {id:5,value:'Organ System Assignment',isSelected:true},
       {id:6,value:'Cell Types',isSelected:true},
       {id:7,value:'Measure',isSelected:true},
       {id:8,value:'Cell Fractions',isSelected:true},
       {id:9,value:'Pattern',isSelected:true},
       {id:10,value:'Status',isSelected:true},
       {id:11,value:'Scientist Name',isSelected:true},
      
     ];
     
    this.getCheckedItemList();
  }
 
  checkUncheckAll() {
    for (var i = 0; i < this.checklist.length; i++) {
      this.checklist[i].isSelected = this.masterSelected;
    }
    for (var i = 0; i < this.checklist2.length; i++) {
      this.checklist2[i].isSelected = this.masterSelected;
    }
    this.getCheckedItemList();
  }

  // Check All Checkbox Checked
  isAllSelected() {
    this.masterSelected = this.checklist.every(function(item:any) {
        return item.isSelected == true;
      })
    this.masterSelected = this.checklist2.every(function(item:any) {
      return item.isSelected == true;
    })
  this.getCheckedItemList();
  this.columnspopUp = false;
  }

  // Get List of Checked Items
  getCheckedItemList(){
    this.checkedList = [];
    for (var i = 0; i < this.checklist.length; i++) {
      if(this.checklist[i].isSelected)
      this.checkedList.push(this.checklist[i]);
    }
  
    for (var i = 0; i < this.checklist2.length; i++) {
      if(this.checklist2[i].isSelected)
      this.checkedList.push(this.checklist2[i]);
    }
   this.headers = []
   for (var i = 0; i < this.checkedList.length; i++) {
  
    this.headers.push(this.checkedList[i]);
  
   }

  }

  openNext() {
    console.log(this.index)
    if(this.productService.currentRole == 'technician'){
      this.index = (this.index === 2) ? 0 : this.index + 1;
    }else{
    setTimeout(() => {
      this.index = (this.index === 2) ? 0 : this.index + 2;
    }, 100);
  }
}

openPrev() {
    this.index = (this.index === 0) ? 2 : this.index - 1;
}

}
