import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TechnicianDefaultComponent } from './technician-default.component';

describe('TechnicianDefaultComponent', () => {
  let component: TechnicianDefaultComponent;
  let fixture: ComponentFixture<TechnicianDefaultComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TechnicianDefaultComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TechnicianDefaultComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
