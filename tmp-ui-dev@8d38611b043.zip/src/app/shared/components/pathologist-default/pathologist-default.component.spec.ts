import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PathologistDefaultComponent } from './pathologist-default.component';

describe('PathologistDefaultComponent', () => {
  let component: PathologistDefaultComponent;
  let fixture: ComponentFixture<PathologistDefaultComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PathologistDefaultComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PathologistDefaultComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
