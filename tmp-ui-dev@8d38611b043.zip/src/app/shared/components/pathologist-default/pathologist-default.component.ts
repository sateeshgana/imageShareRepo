import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ProductService } from '../../../productservice';
import { Product } from '../../../Product';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
@Component({
  selector: 'app-pathologist-default',
  templateUrl: './pathologist-default.component.html',
  styleUrls: ['./pathologist-default.component.css']
})
export class PathologistDefaultComponent implements OnInit {
  pathologistForm: FormGroup;

  // scientistForm2: FormGroup;
  submitted = false;
  products: Product[];


  searchField : '';
  selectedState: any = null;

  states: any[] = [
    { name: "Arizona", code: "Arizona" },
    { name: "California", value: "California" },
    { name: "Florida", code: "Florida" },
    { name: "Ohio", code: "Ohio" },
    { name: "Washington", code: "Washington" }
  ];

  cities1: any[] = [];

  cities2: any[] = [];

  city1: any = null;

  city2: any = null;


  constructor(private formBuilder: FormBuilder, private productService: ProductService,private router:Router) { }
  

  ngOnInit(): void {
    this.pathologistForm = this.formBuilder.group({
      // studeID: ['', Validators.required],
      species: ['', Validators.required],
      targetID: ['', Validators.required],
      // validates date format yyyy-mm-dd
      tissue: ['', [Validators.required]],
      donorID: ['', [Validators.required]],
      format: ['', [Validators.required]],
      matrix: ['', Validators.required],
      technician : ['', Validators.required],
      imageID : ['', Validators.required],
      modality : ['', Validators.required],
      modalityProbe : ['', Validators.required],
      visualisation : ['', Validators.required],
    levels : ['', Validators.required],
  }, );
  }

}
