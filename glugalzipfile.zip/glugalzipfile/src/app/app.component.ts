import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'glugal';
  public showMore = true;
  public showcontent=true;
  public analysis=true;
  
  file=new FormGroup({
    fileUploded:new FormControl('',Validators.required)
  })
  constructor(){
    console.log(this.file)
  }
  moreInfo(){
    this.showMore = false;
    if(this.showcontent=true){
      this.showcontent=true;
    }
   
  }
  content(){
    if(this.showMore=true){
      this.showcontent=false;
    }
  }
  
  runanalysis(){
    this.analysis=false;
  }
 
}
