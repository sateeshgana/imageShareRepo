import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { UtilService } from './services/util.service';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { HttpClient } from '@angular/common/http';
import { DomSanitizer } from '@angular/platform-browser';
import { map } from 'rxjs/operators';



export interface PeriodicElement {
  nearest_compound: string;
  distance: number;
  toxic_level: number;
  Probability: number;
  smile: number;
  jnj_id: number;
  SA_matches: number;
  nearestCompounds: number;
  final_remarks: number;
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  totalCount: any;
  public selectedcomponentsImg: any;
  public selectedCompoundImg: any;


  sanitize(data: any) {
    let jsonArray: any = [];
    Object.entries(data).forEach(([k, v]) => {
      if (typeof v == "object")
        jsonArray.push(v)
    })
    return jsonArray;
  }
  title = 'glugal';
  public showMore = true;
  public showcontent = true;
  public analysis = true;
  public tableData: any = []  // [this.sanitize(this.util.samleData["result"])[0]] ; 
  public formData: any;
  public nearestCompounds: any = [];
  public saMatches: any = [];
  myVar: any = [];
  showPage: any = [];
  public loading = false;

  file = new FormGroup({
    fileUploded: new FormControl('', Validators.required)
  })
  constructor(private util: UtilService, private http: HttpClient, private sanitizer: DomSanitizer) {
    console.log(this.file)
  }
  moreInfo(datas: any, smile: any) {
    if (datas.length > 0) {
      this.selectedCompoundImg = smile;
      this.saMatches = datas
      this.showMore = false;
      if (this.showcontent = true) {
        this.showcontent = true;
      }
    }

  }
  content(data: any, smile: any) {
    this.nearestCompounds = data;
    this.selectedcomponentsImg = smile;
    if (this.showMore = true) {
      this.showcontent = false;
    }
  }

  runanalysis() {
    this.loading = true;
    this.analysis = true;
    const formData = new FormData();
    formData.append('file', this.formData);
    this.util.getGluGalData(formData).subscribe(result => {
      this.tableData = this.sanitize((result as any).result);
      this.totalCount = (result as any).Number_of_mols_EXT_read;
      this.analysis = false;
      this.loading = false;
    })

  }

  onFileSelected(data: any) {
    this.formData = data.files[0];
  }


  downloadCSv(rows: any) {
    let csvContent = "";
    csvContent += "Query,J&J ID,SA Maps,Model prediction,probability \r\n";
    let data = rows;
    data.forEach((rowArray: any) => {
      let saMatches = rowArray["SA_matches"].length > 0 ? rowArray["SA_matches"].join(";") : "";
      let jnjId = rowArray["jnj_id"] ? rowArray["jnj_id"] : '';
      let finalRemarks = rowArray["final_remarks"] ? rowArray["final_remarks"] : '';
      let probability = rowArray["probability"] ? rowArray["probability"] : "";
      let row = `${rowArray["smile"]}, ${jnjId}, ${saMatches}, ${finalRemarks}, ${probability}`;
      csvContent += row + "\r\n";
    });
    var encodedUri = encodeURIComponent(csvContent);
    console.log(encodedUri);
    var link = document.createElement("a");
    link.setAttribute("href", "data:text/csv;charset=utf-8,%EF%BB%BF" + encodedUri);
    link.setAttribute("download", "mitotox_glugal_alert_results_" + new Date().getTime() + ".csv");
    document.body.appendChild(link); // Required for FF
    link.click(); // This will download the data file named "my_data.csv"
  }


  displayedColumnsLeft: string[] = ['nearest_compound', 'distance', 'toxic_level'];
  displayedColumnsRight: string[] = ['smile', 'jnj_id', 'SA_matches', 'nearestCompounds', 'final_remarks', 'Probability']


  generatePdf(exportContent: any, fileName: any) {

    var quotes: any = document.getElementById(exportContent);
    html2canvas(quotes, {
      useCORS: true, onclone: (documentClone: any) => {
        documentClone.querySelector('#' + exportContent).style.overflow = "initial";
        documentClone.querySelector('#' + exportContent).style.overflowX = "initial";
        documentClone.querySelector('#' + exportContent).style.maxHeight = "initial";
        documentClone.querySelector('#' + exportContent).style.width = "900px";
        documentClone.querySelector('#download').style.display = "none";
        let x = documentClone.querySelectorAll(".smile-str");
        x.forEach((element: any) => {
          element.style.display = "inline-block";
        });

      }
    })
      .then((canvas) => {
        //! MAKE YOUR PDF
        var pdf = new jsPDF('p', 'pt', 'letter');

        for (var i = 0; i <= quotes.clientHeight / 980; i++) {
          //! This is all just html2canvas stuff
          var srcImg = canvas;
          var sX = 0;
          var sY = 980 * i; // start 980 pixels down for every new page
          var sWidth = 900;
          var sHeight = 980;
          var dX = 0;
          var dY = 0;
          var dWidth = 900;
          var dHeight = 980;

          (window as any).onePageCanvas = document.createElement("canvas");
          (window as any).onePageCanvas.setAttribute('width', 900);
          (window as any).onePageCanvas.setAttribute('height', 980);
          var ctx = (window as any).onePageCanvas.getContext('2d');
          ctx.drawImage(srcImg, sX, sY, sWidth, sHeight, dX, dY, dWidth, dHeight);

          // document.body.appendChild(canvas);
          var canvasDataURL = (window as any).onePageCanvas.toDataURL("image/png", 1.0);

          var width = (window as any).onePageCanvas.width;
          var height = (window as any).onePageCanvas.clientHeight;

          //! If we're on anything other than the first page,
          // add another page
          if (i > 0) {
            pdf.addPage("612", "landscape"); //8.5" x 11" in pts (in*72)
          }
          //! now we declare that we're working on that page
          pdf.setPage(i + 1);
          //! now we add content to that page!
          pdf.addImage(canvasDataURL, 'PNG', 5, 20, (width * .62), (height * .5));

        }
        //! after the for loop is finished running, we save the pdf.
        pdf.save(`${fileName}_${new Date().getTime()}.pdf`);
      });
  }

  getSanitizeUrl(url: any) {
    //return "http://localhost:4200/assets/images/imageShareRepo-main/Frame%2040.png";
    return `http://localhost:5000/smile_upload/${encodeURIComponent(url)}`;
  }
}
