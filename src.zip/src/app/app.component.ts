import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { UtilService } from './services/util.service';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';


export interface PeriodicElement {
  nearest_compound: string;
  distance: number;
  toxic_level: number;
  Probability: number;
  smile: number;
  jnj_id: number;
  SA_matches: number;
  nearestCompounds: number;
  final_remarks: number;
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  totalCount:any;

  sanitize(data: any) {
    let jsonArray: any = [];
    Object.entries(data).forEach(([k, v]) => {
      if(typeof v == "object")
      jsonArray.push(v)
    })
    console.log(jsonArray);
    return jsonArray;
  }
  title = 'glugal';
  public showMore = true;
  public showcontent = true;
  public analysis = true;
  public tableData: any  =  [];// this.sanitize(this.util.samleData["result"]); 
  public formData: any;
  public nearestCompounds: any = [];
  public saMatches: any = [];
  myVar:any=[];
  showPage:any=[];
  public loading=false;

  file = new FormGroup({
    fileUploded: new FormControl('', Validators.required)
  })
  constructor(private util: UtilService) {
    console.log(this.file)
  }
  moreInfo(datas: any) {
    this.saMatches = datas
    this.showMore = false;
    if (this.showcontent = true) {
      this.showcontent = true;
    }

  }
  content(data: any) {
    this.nearestCompounds = data;
    if (this.showMore = true) {
      this.showcontent = false;
    }
  }

  runanalysis() {
    this.loading=true;
   // this.analysis=false;
    const formData = new FormData();
    formData.append('file', this.formData);
     this.util.getGluGalData(formData).subscribe(result =>{
        this.tableData = this.sanitize((result as any).result); 
        this.totalCount =  (result as any).Number_of_mols_EXT_read;
        this.analysis=false;
        this.loading = false;
      })
  //  this.analysis = false;
  //   this.tableData = this.sanitize(this.util.samleData["result"]); 
  //   setTimeout(()=>{this.loading = false;}, 300);
  }

  onFileSelected(data: any) {
    this.formData = data.files[0];
  }
  
  
  downloadCSv(rows: any) {
    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent+="Query,J&J ID,SA Maps,Model prediction,probability \r\n";
    let data = rows;
    data.forEach((rowArray: any) => {
      let row =rowArray["smile"]+","+rowArray["jnj_id"]+","+rowArray["SA_matches"]+","+rowArray["final_remarks"]+","+rowArray["probability"];
      csvContent += row + "\r\n";
    });
    var encodedUri = encodeURI(csvContent);
    var link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", "data.csv");
    document.body.appendChild(link); // Required for FF
    link.click(); // This will download the data file named "my_data.csv"
  }


  displayedColumnsLeft: string[] = ['nearest_compound', 'distance', 'toxic_level'];
  displayedColumnsRight: string[] = ['smile', 'jnj_id', 'SA_matches', 'nearestCompounds', 'final_remarks', 'Probability']

  generatePdf(exportContent:any) {
    //alert();

    const div:any = document.getElementById(exportContent);

    html2canvas(div, {useCORS: true,}).then(canvas => {
    // Few necessary setting options
    const imgWidth = 208;
    const imgHeight = canvas.height * imgWidth / canvas.width;

    const contentDataURL = canvas.toDataURL('image/png')
    let pdf = new jsPDF('p', 'mm', 'a4'); // A4 size page of PDF
    var position = 0;
    pdf.addImage(contentDataURL, 'PNG', 2, position, imgWidth, imgHeight)
    pdf.save('glu-gal-export-file'); // Generated PDF
    });
  


    
  }
}
